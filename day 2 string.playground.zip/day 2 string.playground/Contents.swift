//: Playground - noun: a place where people can play

import UIKit

var a=[10,20,30,40]   ///array
print("a[0]:\(a[0])")
print(a)
let x1 = [10,20]
print("x1",x1)
//use method to add values

var b = [Int]();
print("size of array b : \(b.count)")
b.append(1000)
 b[0] = 1000
print(b)
print("size of array b:m \(b.count)")          ///size of array
b.append(1000)
b[1] = 1000
print(b)
//index out of range
// b[2]=500

var num1=[Int](repeating:5,count:3) //// 5,5,5
print(num1 )
var num2=[Int](repeating:1,count:3)
var merge = num1+num2
print (merge)
var c = [Any]();
print ("size of c\(c.count)")
c.append(100)
c.append("keshav")
c.append(5250)
print ("c",c)
 
var shoppingListr:[String] = ["eggs","milk"]
for(index,value) in shoppingListr.enumerated()
{print("item \(index):\(value)")

}
var grades : Set<Character> = []
grades.insert("a")
grades.insert("b")
print(grades)
print(grades.count)
//var gradeType: Set <Any> = [] set contains only hashable

var favgenres: Set<String> = ["Rock","Classical","Hip hop"]

print("Favgenres: \(favgenres)")

print("I have \(favgenres.count) fav music genres.")

if favgenres.isEmpty {
    
    print("As far as music goes,I'm picky")
    
    
    
}
let oddDigits: Set =[1,3,5,7,9]
let evenDigits: Set =[]
    
    
    
else{
    
    print("I have particular music preferences.")
    
    
    
}

favgenres.insert("jazz")

print("favgenres:\(favgenres)")

if let removedgenre = favgenres.remove("Rock") {
    
    print("\(removedgenre)? I 'am over it")
    
}
    
else {
    
    print(" I never much cared for that")
    
}

print("favgenres:\(favgenres)")

for genre in favgenres.sorted() {
    
    print("\(genre)")
    
}

