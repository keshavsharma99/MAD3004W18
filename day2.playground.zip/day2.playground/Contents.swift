//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)
let str1 = """
on1
two
three
"""
print(str1)
var mood = ""
let heart = "\u{1f496}"
mood = "happy"
 if mood.isEmpty
{
    print("cheer up")
 } else{
    print(heart)
}
mood += "cheerful joyful"
print(mood)
//heart += "be happy"
var firstname = String()
firstname = "JKighkj"
print (firstname)
for i in firstname {
    print (i)
}
let initial : Character = "j"
firstname .append(initial)
print(firstname)
print("first is \(firstname) which is \(firstname.count) characters long.")
print ("start Index:" , firstname[firstname.startIndex])
print ("before end index:", firstname[firstname.index(before: firstname.endIndex)])
print ("after start index;",firstname[firstname.index(after: firstname.startIndex)])
print("5th character", firstname [firstname.index(firstname.startIndex,offsetBy:2)])
var idx = firstname.index(firstname.startIndex,offsetBy: 3)
print ("fourth character",firstname[idx])


let name = "keshav"
let stringlength = name.count
print("length of name ",stringlength)
for i in name
{
    print(i)
}

//*var language = "swift"

//print("language : ", language)
//language.insert("!",at: language.endIndex)
//print("language :", language )
//land

































var a =[10,30,60,70,80]
