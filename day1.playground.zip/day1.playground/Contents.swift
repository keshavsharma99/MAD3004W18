//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)
print(" need a rest: \(str)",terminator:" ")// use term which ends th statement and start with another statement
print("22","33","44","23","3",separator: "\n") // use separator
var n1=10
print ("number 1 :",n1,"string :",str)
//var n1 = 10
print("Number 1 : ",n1,"String :",str)


var n2=20
print ("number 2:",2)
var sum=n1+n2
print("sum is :",sum)
print("sum =", n1+n2)

var a:Int = 10

print("a = ",a)
var greet:String = "goodmorning"
print("greetings : ",greet)
var emoji = "👀";
print("nav kahan ho arpan",emoji)
let pi = 3.14
 //var  = 3.190
print ("pi = ",pi)
let myNum:Int?
myNum=10
if myNum != nil
{
    print("mynum : ",myNum!)
}
else{
    print("mynum is nill")

}
let possibleNumber = "123"
let convertedNumber:Int?
convertedNumber = Int (possibleNumber)
if convertedNumber != nil
{
    
     print("converted  Number" , convertedNumber!)
    
}
else {
    print("nil")
}
for i in 1..<5 {
    print("i =",i)
}
let languages :[String]
languages =  ["eng","spanish","frech"]
for i in languages{
print ("language : ", i)
}
let number :[String]
number = ["3","2","3","5"]

for k in number
{
    print(number)
}
var Interval : Int = 5
for i in stride(from: 0, to: 50, by: Interval)
{
    print (i,"",terminator: " ")
}
var j=1
while (j < 5)
{
    print ( "value of j is \(j)")
j = j+1
    
}
j = 5
repeat {
    print ("Repeat :",j)
    j = j+2
} while (j<=10)


var num1=10
switch num1{
case 100 :
    print ("value of num1 is 100")
case 10,15 :
    print("value of num1 is either 10 or 15")
case 5:
    print ("value of num1 is 5")
    default :
    print("default case")
}
let countedThings = "moons orbitings  saturn"
let naturalCount  
